module.exports = {
    //url: "http://localhost:3032"
    url: "https://minisitio.online/api"
}