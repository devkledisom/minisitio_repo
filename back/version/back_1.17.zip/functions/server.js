const xl = require('excel4node');
const wb = new xl.Workbook();
const ws = wb.addWorksheet('espacos');
const path = require('path');

module.exports = function expExcel(dados, res) {
    const data = [
        {
            name: "teste",
            email: "teste@hot.com",
            celular: "736478236"
        },
        {
            name: "person",
            email: "person@hot.com",
            celular: 736478236
        }
    ];
    
    const headingColumnNames = [
        "codAnuncio",
        "Usuario",
        "Tipo",
        "duplicado",
        "Caderno",
        "UF",
        "Anuncio",
         "Telefone",
        "Whatsapp",
        "CPFCNPJ",
        "EmailAutorizante",
       "IDDesconto",
        "Status",
        "Cadastro",
        "DataFim",
        "LinkMINISITIO",
        "Login",
        "Senha",
        "PagamentoValor"
    ];
    
    let headingColumnIndex = 1;
    headingColumnNames.forEach(heading => {
        ws.cell(1, headingColumnIndex++).string(heading);
    });
    
    let rowIndex = 2;
    dados.forEach((record, index) => {
        let columnIndex = 1;
        Object.keys(record).forEach((columnName) => {
            
          /*   if(typeof(record[columnName]) == "string") {
                //console.log(typeof(record[columnName]))
                ws.cell(rowIndex, columnIndex++).string(record[columnName]);
            } else {
                ws.cell(rowIndex, columnIndex++).number(record[columnName]);
            }; */
            
            const value = record[columnName];

            if (value === null || value === undefined) {
                ws.cell(rowIndex, columnIndex++).string("0");
            } else if (typeof value === "string") {
                ws.cell(rowIndex, columnIndex++).string(value);
            } else if (typeof value === "number") {
                ws.cell(rowIndex, columnIndex++).number(value);
            } else {
                // Opcional: Se você tiver outros tipos de dados para lidar
                ws.cell(rowIndex, columnIndex++).string(value.toString());
            }

        });
        rowIndex++;

        if (dados.length == index + 1) {
            res.json({ success: true, message: "Exportação Finalizada", downloadUrl: "https://minisitio.online/api/export/arquivo.xlsx"});
        };
    });

    console.log("gerando")
    
    wb.write(path.join(__dirname, '../public/export/arquivo.xlsx'));

}
