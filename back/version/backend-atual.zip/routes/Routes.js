const express = require('express');
const router = express.Router();


//Controllers
const BemVindo = require('../controllers/BemVindo');
const Buscador = require('../controllers/Buscador');
const Admin = require('../controllers/Admin');
const Login = require('../controllers/Login');
const Users = require('../controllers/Users');
const Upload = require('../controllers/upload');

//middleware
router.use(function timelog(req, res, next) {
    console.log('Time: ', Date.now());
    next();
});

const uploadUser = require('../middlewares/uploadImage');


router.get('/', BemVindo.bemvindo);

//buscador
router.post('/buscar', Buscador.busca);
router.get('/cadernos', Buscador.buscarCaderno);
router.get('/ufs', Buscador.buscarUf);
router.post('/anuncios/:codCaderno', Buscador.buscaGeralCaderno);
router.get('/atividade/:codAtividade', Buscador.buscaAtividade);
router.get('/anuncio/:codAnuncio', Buscador.buscaAnuncio);
router.get('/admin/usuario', Admin.listarUsuarios);

//Login
router.post('/entrar', Login.login);

//Admin
router.post('/admin/usuario/create', Users.create);
router.post('/admin/usuario/update/:id', Users.update);
router.get('/admin/usuario/edit/:id', Users.buscarUsuario);
router.delete('/admin/usuario/delete/:id', Users.delete);
router.get('/admin/cadernos', Admin.listarCadernos);

//site
router.post('/admin/usuario/criar-anuncio', Users.criarAnuncio);
router.get('/pa', Users.qtdaAnuncio);
router.post('/upload-image', uploadUser.single('image'), Upload.uploadImg);
router.get('/list-image', Upload.listFiles);


module.exports = router;
