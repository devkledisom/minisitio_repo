const ButtonActivate = () => {
    return (
        <div>

        </div>
    );
};

export default ButtonActivate;