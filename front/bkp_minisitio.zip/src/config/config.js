export const masterPath = {
    //url: "http://localhost:3032/api"
    url: "https://minisitio.online/api"
}