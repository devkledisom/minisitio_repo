export const masterPath = {
    //url: "http://192.168.0.127:3032"
    url: "https://minisitio.online/api"
}