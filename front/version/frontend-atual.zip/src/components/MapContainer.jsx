import React from "react";
/* import GoogleMapReact from 'google-map-react'; */
import { GoogleMap, StreetViewPanorama, LoadScript } from '@react-google-maps/api';

//const AnyReactComponent = ({ text }) => <div>{text}</div>;

export default function MapContainer() {

    const apiKey = 'AIzaSyBpuxjyShwHApt-FthqurSP4G0xx7nznl0';

    const containerStyle = {
        width: '100%',
        height: '400px',
    };

    const center = {
        lat: -34.397,
        lng: 150.644,
    };

    const streetViewPanoramaOptions = {
        position: center,
        pov: { heading: 100, pitch: 10 },
        zoom: 1,
    };

    return (
        <LoadScript googleMapsApiKey={apiKey}>
            <GoogleMap
                mapContainerStyle={containerStyle}
                center={center}
                zoom={10}
            >
                <StreetViewPanorama options={streetViewPanoramaOptions} />
            </GoogleMap>
        </LoadScript>
    );

    /*  const defaultProps = {
         center: {
             lat: -10.307270115874669,//10.99835602, 
             lng: -36.585319982985084
         },
         zoom: 11
     };
 
 
 
     return (
         // Important! Always set the container height explicitly
         <div style={{ height: '50vh', width: '100%' }}>
             <GoogleMapReact
                 bootstrapURLKeys={{ key: "AIzaSyBpuxjyShwHApt-FthqurSP4G0xx7nznl0" }}
                 defaultCenter={defaultProps.center}
                 defaultZoom={defaultProps.zoom}
                 visible
             >
                 <AnyReactComponent
                     lat={59.955413}
                     lng={30.337844}
                     text="My Marker"
                 />
 
                 <StreetViewPanorama
                     defaultPosition={defaultProps.center}
                     visible
                 />
 
 
             </GoogleMapReact> 
         </div>
     );*/
}
